const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Cambia esto por tu usuario
    password: '', // Cambia esto por tu contraseña
    database: 'registro_personal'
});

db.connect((err) => {
    if (err) { throw err; }
    console.log('Conectado a la base de datos');
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.post('/registro', (req, res) => {
    const { nombre, apellidos, edad, id_universidad, genero, ultimo_libro_prestado, fecha_prestamo, fecha_devolucion } = req.body;
    const query = 'INSERT INTO registros (nombre, apellidos, edad, id_universidad, genero, ultimo_libro_prestado, fecha_prestamo, fecha_devolucion) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
    db.query(query, [nombre, apellidos, edad, id_universidad, genero, ultimo_libro_prestado, fecha_prestamo, fecha_devolucion], (err, result) => {
        if (err) {
            console.error('Error al insertar datos en la base de datos:', err);
            res.status(500).json({ message: 'Error al guardar los datos' });
            return;
        }
        console.log('Datos insertados correctamente en la base de datos');
        res.status(201).json({ message: 'Datos guardados con éxito' });
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en el puerto ${PORT}`);
});