document.addEventListener("DOMContentLoaded", function() {
  const generoSelect = document.getElementById("genero_literario");
  const librosContainer = document.getElementById("libros_container");
  const librosSelect = document.getElementById("libro_seleccionado");
  
  const librosPorGenero = {
      Novela: ["El amor en los tiempos del cólera", "Cien años de soledad", "Don Quijote de la Mancha", "Orgullo y prejuicio", "1984"],
      Poesía: ["Cien sonetos de amor", "Veinte poemas de amor y una canción desesperada", "El corazón delator", "Las flores del mal", "La divina comedia"],
      "Ciencia ficción": ["El fin de la eternidad", "Fundación", "El marciano", "Neuromante", "Dune"],
      Fantasía: ["El señor de los anillos", "Harry Potter y la piedra filosofal", "Las crónicas de Narnia", "Juego de tronos", "Crónicas del mago negro"],
      Misterio: ["El código Da Vinci", "Asesinato en el Orient Express", "Sherlock Holmes", "La chica del tren", "El nombre de la rosa"],
      Romance: ["Orgullo y prejuicio", "Romeo y Julieta", "Bajo la misma estrella", "Como agua para chocolate", "La pareja de al lado"],
      Terror: ["El exorcista", "It", "El resplandor", "Drácula", "Frankenstein"],
      Drama: ["Los miserables", "El diario de Ana Frank", "Mil soles espléndidos", "El paciente inglés", "El curioso incidente del perro a medianoche"],
      Aventura: ["Las aventuras de Tom Sawyer", "La isla del tesoro", "Moby Dick", "Viaje al centro de la Tierra", "Robinson Crusoe"],
      Historia: ["Los pilares de la Tierra", "El médico", "Sapiens: De animales a dioses", "Breve historia del tiempo", "Una historia de España"]
  };

  function actualizarLibros() {
      const generoSeleccionado = generoSelect.value;
      librosSelect.innerHTML = "<option value=''>Selecciona un libro</option>";
      
      if (generoSeleccionado && librosPorGenero[generoSeleccionado]) {
          librosPorGenero[generoSeleccionado].forEach(libro => {
              const option = document.createElement("option");
              option.text = libro;
              option.value = libro;
              librosSelect.add(option);
          });
          librosContainer.style.display = "block";
      } else {
          librosContainer.style.display = "none";
      }
  }
  
  generoSelect.addEventListener("change", actualizarLibros);
});